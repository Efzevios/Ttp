# Dependências — TRADUZIR (Debian 13)

O projeto usa **Bash 5+** e **Python 3**. As dependências abaixo estão divididas entre as essenciais e as específicas de cada mecanismo. **Não é necessário instalar todos os mecanismos para usar somente a OpenRouter.**

## 1. Essenciais (todos os modos)

```bash
sudo apt update
sudo apt install -y bash python3 coreutils grep sed gawk findutils locales ca-certificates
```

Comandos utilizados pelo projeto: `bash`, `python3`, `cat`, `wc`, `sha256sum`, `mktemp`, `mkfifo`, `timeout`, `date`, `stat`, `cp`, `mv`, `rm`, `mkdir`, `grep`, `sort` e `locale`. A maioria vem de `coreutils`; `grep` e `sort` são pacotes padrão.

## 2. APIs de IA: OpenRouter, Gemini, OpenAI e Anthropic

```bash
sudo apt install -y pipx python3-venv
pipx ensurepath
pipx install llm
pipx inject llm llm-openrouter llm-gemini llm-anthropic
```

Se `llm` já estiver instalado via `pipx`, **não reinstale**: execute apenas `pipx inject llm ...` para os plugins ausentes. Garanta que `~/.local/bin` esteja no `PATH` e tenha prioridade sobre `/usr/bin`.

O suporte à OpenAI já vem no `llm` e não precisa de plugin extra.

Para habilitar a OpenRouter, obtenha uma chave em <https://openrouter.ai/keys>, e configure-a **no seu arquivo local**, nunca no repositório público:

```bash
llm keys set openrouter
llm openrouter refresh
llm openrouter models --free
llm models list | grep -i openrouter
```

Edite `TRADUZIR_OPENROUTER_KEYS` e `TRADUZIR_MODELOS_OPENROUTER` em `credenciais_modelos.sh`. As duas configurações são independentes: `llm keys set` habilita o catálogo do plugin; a lista de chaves alimenta a rotação do `traduzir`.

**Atenção:** a disponibilidade e as cotas dos modelos `:free` mudam. Os identificadores do exemplo são candidatos fornecidos para a configuração e devem ser conferidos com `llm models list` antes do uso.

O `extra-openai-models.yaml` **não é necessário para a OpenRouter**. Se você já tiver esse arquivo e ele estiver vazio, coloque `[]` para evitar `TypeError: 'NoneType' object is not iterable`. Não sobrescreva configurações de outros provedores.

## 3. Tradução online sem chave: translate-shell

```bash
sudo apt install -y translate-shell
trans -b en:pt-BR 'Hello world'
```

No Debian 13, `translate-shell` pertence ao componente **contrib**. Se o `apt` não encontrar o pacote, habilite `contrib` nas fontes APT antes de repetir a instalação. Requer acesso à internet; a disponibilidade dos serviços externos pode variar.

## 4. Tradução offline: Apertium

```bash
sudo apt install -y apertium apertium-eng-spa apertium-es-pt
apertium -l
```

Esses pacotes fornecem uma possível **rota via espanhol**, não necessariamente um par direto inglês → português. O `traduzir` **não usa essa rota automaticamente**: consulte os modos com `apertium -l` e, se existirem os dois, configure explicitamente `TRADUZIR_APERTIUM_MODOS` no seu arquivo local, com os nomes reais (por exemplo, `eng-spa,es-pt`).

## 5. Tradução offline: Argos Translate

```bash
pipx install argostranslate
argospm update
argospm search --from-lang en --to-lang pb
argospm install translate-en_pb
argospm list
```

O último `install` só funciona se `translate-en_pb` estiver disponível no índice; confira a saída do `search` antes de executar. O modelo de idioma é um download separado e pode ocupar bastante espaço.

## 6. Documentação GNU/Linux em português (opcional)

```bash
sudo apt install -y man-db manpages-pt-br manpages-pt-br-dev
sudo dpkg-reconfigure locales
locale -a | grep -i pt_BR
```

Se sua distribuição não disponibilizar algum pacote, consulte `apt search manpages-pt-br`. É necessário ter `pt_BR.UTF-8` gerado para algumas traduções de ajuda nativa.

## 7. Instalação guiada por componentes

O arquivo `instalar_dependencias.sh` automatiza a instalação no Debian 13:

```bash
bash instalar_dependencias.sh --basico --apis
bash instalar_dependencias.sh --shell --apertium --argos --man
bash instalar_dependencias.sh --tudo
```

Ele não instala nem publica chaves de API. A instalação do modelo de idiomas Argos é feita separadamente após consultar o índice.

## 8. Verificação

```bash
bash -n traduzir.bash
bash -n credenciais_modelos.sh
llm plugins
llm models list | grep openrouter
command -v trans apertium argos-translate
```

Documentação de referência:
- LLM: <https://llm.datasette.io/>
- Plugin OpenRouter: <https://github.com/simonw/llm-openrouter>
- Argos Translate: <https://github.com/argosopentech/argos-translate>
- Pacotes Debian: <https://packages.debian.org/trixie/>
