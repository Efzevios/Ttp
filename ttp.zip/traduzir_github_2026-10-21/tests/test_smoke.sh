#!/usr/bin/env bash
set -euo pipefail

projeto=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)
for arquivo in traduzir.bash credenciais_modelos.sh.example instalar_dependencias.sh; do
    bash -n "$projeto/$arquivo"
done
if grep -n '#' "$projeto/credenciais_modelos.sh.example"; then
    printf 'ERRO: configuração pública contém comentários #\n' >&2
    exit 1
fi

tmp=$(mktemp -d)
trap 'rm -rf -- "$tmp"' EXIT
mkdir -p "$tmp/bin" "$tmp/projeto"
cp "$projeto/traduzir.bash" "$tmp/projeto/traduzir.bash"
cat > "$tmp/projeto/credenciais_modelos.sh" <<'EOF'
TRADUZIR_GEMINI_KEYS=()
TRADUZIR_OPENAI_KEYS=()
TRADUZIR_ANTHROPIC_KEYS=()
TRADUZIR_OPENROUTER_KEYS=('teste-openrouter')
TRADUZIR_MODELOS_GEMINI=()
TRADUZIR_MODELOS_OPENAI=()
TRADUZIR_MODELOS_ANTHROPIC=()
TRADUZIR_MODELOS_OPENAI_COMPATIVEIS=()
TRADUZIR_MODELOS_OPENROUTER=('openrouter/nvidia/nemotron-3-super-120b-a12b:free')
TRADUZIR_MODO_SEM_TTY=api
TRADUZIR_MAX_TENTATIVAS=1
TRADUZIR_NATIVO_MAN=0
TRADUZIR_NATIVO_AJUDA=0
TRADUZIR_CACHE=0
TRADUZIR_ORGANIZAR=0
EOF
cat > "$tmp/bin/llm" <<'EOF'
#!/usr/bin/env bash
if [[ ${OPENROUTER_KEY:-} != 'teste-openrouter' ]]; then
    echo 'Chave OpenRouter não recebida' >&2
    exit 12
fi
if [[ "$*" != *'openrouter/nvidia/nemotron-3-super-120b-a12b:free'* ]]; then
    echo 'Modelo incorreto' >&2
    exit 13
fi
cat >/dev/null
printf 'Olá, mundo!\n'
EOF
chmod +x "$tmp/bin/llm"
export PATH="$tmp/bin:$PATH" TRADUZIR_DIR="$tmp/saidas"
resultado=$(bash -c 'source "$1"; printf "Hello world\n" | traduzir' _ "$tmp/projeto/traduzir.bash" 2>"$tmp/erro") || {
    cat "$tmp/erro" >&2
    printf 'ERRO: falha no teste de integração.\n' >&2
    exit 1
}
if [[ "$resultado" != *'Olá, mundo!'* ]]; then
    printf 'ERRO: resposta inesperada: %s\n' "$resultado" >&2
    cat "$tmp/erro" >&2
    exit 1
fi
if grep -q 'teste-openrouter' "$tmp/erro"; then
    printf 'ERRO: chave exposta no diagnóstico.\n' >&2
    exit 1
fi
printf 'OK: sintaxe Bash, template sem comentários e OpenRouter simulado.\n'
